package kr.co.greenart.notice.controller;

import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import kr.co.greenart.common.model.dto.PageInfo;
import kr.co.greenart.common.template.Pagination;
import kr.co.greenart.notice.model.dto.Notice;
import kr.co.greenart.notice.model.service.NoticeServiceImpl;

@Controller
@RequestMapping("/notice")    // http://localhost/board/list.do
public class NoticeController {

	// GET : URL 정보 보임, 중요도 낮은 정보들(ex. 검색, 페이지이동)
	// POST : URL 정보 X, 네트워크 패킷 body 안에 데이터가 들어감
	//        중요한 정보들 (회원가입, 로그인, 결제)
	
	// RequestMapping  :  GET, POST
	// GetMapping  :  GET
	// PostMapping  :  POST
	
	@Autowired
	private NoticeServiceImpl noticeService;
	
//	@Autowired
//	private Login LoginCheck;
	
	@GetMapping("/list.do")
	public String noticeList(@RequestParam(value="cpage", defaultValue="1") int currentPage, 
							Model model,
							HttpSession session) {
//		Login loginCheck = new Login();	
		
//		if(Login.loginCheck(session)) {
			// 전체 게시글 수 구하기
			int listCount = noticeService.selectListCount();                                                             
			
			// 보여질 페이지 수
			int pageLimit = 10;
			
			// 한 페이지에 보여질 게시글 수
			int boardLimit = 15;
			
			// 글 번호 뒤에서부터 출력해주는 변수
			int row = listCount - (currentPage-1) * boardLimit;
			
			// 페이징 로직 처리
			PageInfo pi = Pagination.getPageInfo(listCount, currentPage, pageLimit, boardLimit);
			
			if(currentPage > pi.getMaxPage()) {
				pi.setCurrentPage(pi.getMaxPage());
			}
			
			// 목록 불러오기
			List<Notice> list = noticeService.selectListAll(pi);
			
			for(Notice item : list) {
				item.setCreateDate(item.getCreateDate().substring(0, 10));
			}
			
			// 로그인 메시지
			String msg = (String) session.getAttribute("msg");
			String status = (String) session.getAttribute("status");
			
			System.out.println(pi.getEndPage());
			System.out.println(pi.getMaxPage());
			
			model.addAttribute("list", list); // 객체 바인딩
			model.addAttribute("pi", pi);
			model.addAttribute("row", row);
			model.addAttribute("msg", msg);
			model.addAttribute("status", status);
			
			session.removeAttribute("msg");
			session.removeAttribute("status");
			
			return "notice/noticeList";
//		} 
//	else {
//			model.addAttribute("msg", "잘못된 접근입니다.");
//			model.addAttribute("status", "error");
//			return "member/login";
//		}
	}
	
}









