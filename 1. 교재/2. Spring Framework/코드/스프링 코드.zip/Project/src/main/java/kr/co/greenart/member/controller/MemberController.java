package kr.co.greenart.member.controller;

import java.util.Objects;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import kr.co.greenart.member.model.dto.Member;
import kr.co.greenart.member.model.service.MemberServiceImpl;

@Controller
@RequestMapping("/member")
public class MemberController {

	@Autowired
	MemberServiceImpl memberService;
	
	@Autowired
	BCryptPasswordEncoder bcryptPasswordEncoder;
	
	@PostMapping("/login.do")
	public String loginIndex(Member m, HttpSession session, Model model) {
		Member loginUser = memberService.loginMember(m);
		// Objects.isNull(loginUser) = null : true
		// !(논리부정) null : false , notNull : true
		// !true
		if(!Objects.isNull(loginUser) && bcryptPasswordEncoder.matches(m.getMemberPassword(), loginUser.getMemberPassword())) {                                          
			session.setAttribute("memberIdx", loginUser.getMemberIdx());
			session.setAttribute("memberName", loginUser.getMemberName());
			session.setAttribute("msg", "로그인 되었습니다.");
			session.setAttribute("status", "success");
			return "redirect:/board/list.do";
		} else { // 로그인 실패
			model.addAttribute("msg", "아이디 또는 비밀번호를 확인해주세요.");
			model.addAttribute("status", "error");
			return "/member/login";
		}
	}
	
	@GetMapping("/registerForm.do")
	public String registerForm() {
		return "member/registerForm";
	}
	
	@PostMapping("/register.do")
	public String register(Member member) {
		// 유효성 검사
		String password = member.getMemberPassword(); // qwer1234!
		String passwordChk = member.getMemberPasswordChk();  // qwer
		String email = member.getMemberEmail(); // test@test.com
		
		String emailRegex = "^[A-Za-z0-9+_.-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}$";
		String passwordRegex = "^(?=.*[a-zA-Z])(?=.*[@$!%*?&#])[A-Za-z\\d@$!%*?&#]{6,20}$";
		
		// 이메일 검증
		String isEmailAvailable = checkEmail(email);
		
		if(password.matches(passwordRegex) && password.equals(passwordChk) &&
		   isEmailAvailable.equals("success") && email.matches(emailRegex)) {
			// 패스워드 암호화
			String bcryptPassword = bcryptPasswordEncoder.encode(member.getMemberPassword());
			member.setMemberPassword(bcryptPassword);
			
			// 회원가입
			int result = memberService.registerMember(member);
			
			if(result > 0) {
				return "member/login";
			} else {
				return "common/errorPage";
			}
		} else {
			return "common/errorPage";
		}
  		
	}
	
	@PostMapping("/checkEmail.do")
	@ResponseBody
	// HTTP body에 return값을 응답으로 보냄
	public String checkEmail(String email) {
		// COUNT(*)
		// MemberService에 checkEmail 추상 메서드
		// MemberServiceImpl에 checkEmail 메서드
		// MemberDao에 메서드
		int result = memberService.checkEmail(email);
		
		if(result > 0) {
			return "failed";
		} else {
			return "success";
		}
		
		// ResponseBody 쓰지않을 경우 : /WEB-INF/views/success.jsp를 찾아감
		// ResponseBody 쓸 경우 : 문자열 success를 클라이언트에게 반환
	}
	
	
	
	
	@GetMapping("/redirect.do")
	public String redirectIndex(Model model) {
		model.addAttribute("msg", "잘못된 접근입니다.");
		model.addAttribute("status", "error");
		return "member/login";
	}
	
	// localhost/board/list.do
	// 로그인페이지로 이동(http://localhost/member/redirect.do)
}



















