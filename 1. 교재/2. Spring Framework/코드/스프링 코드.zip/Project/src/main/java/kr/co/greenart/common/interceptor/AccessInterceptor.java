package kr.co.greenart.common.interceptor;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.lang.Nullable;
import org.springframework.web.method.HandlerMethod;
import org.springframework.web.servlet.HandlerInterceptor;
import org.springframework.web.servlet.ModelAndView;

// HandlerInterceptor 컨트롤+좌클릭
// 97~151라인 복사+붙여넣기
// 주석 제거
public class AccessInterceptor implements HandlerInterceptor {
	
	public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler)
			throws Exception {
		
//		String referer = request.getHeader("referer");
//		
//		String requestURI = request.getRequestURI();
//		String serverAddress = request.getRequestURL().toString();
//		
//		System.out.println("referer : " + referer);
//		System.out.println("requestURI : " + requestURI);
//		System.out.println("serverAddress : " + serverAddress);
//		
//		String localServerAddress = serverAddress.replace(requestURI, "");
//		
//		if(requestURI.equals("/free/detail.do") && 
//		   (referer == null || !referer.startsWith(localServerAddress+"/free/list.do"))) {
//			
//			response.sendRedirect("common/errorPage");
//			return false;
//		}
		

		
		
		return true;
	}
	
	public void postHandle(HttpServletRequest request, HttpServletResponse response, Object handler,
			@Nullable ModelAndView modelAndView) throws Exception {
	}

	public void afterCompletion(HttpServletRequest request, HttpServletResponse response, Object handler,
			@Nullable Exception ex) throws Exception {
	}
}
