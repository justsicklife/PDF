package kr.co.greenart.board.model.service;

import java.util.List;

import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import kr.co.greenart.board.model.dao.BoardDao;
import kr.co.greenart.board.model.dto.Board;
import kr.co.greenart.common.model.dto.PageInfo;

@Service
public class BoardServiceImpl implements BoardService {

	@Autowired
	private BoardDao boardDao;
	
	@Autowired
	private SqlSessionTemplate sqlSession;
	
	@Override
	public int selectListCount() {
		return boardDao.selectListCount(sqlSession);
	}
	
	@Override
	public List<Board> selectListAll(PageInfo pi) {
		return boardDao.selectListAll(sqlSession, pi);
	}

	@Override
	public int insertBoard(Board board) {
		return boardDao.insertBoard(sqlSession, board);
	}
	
	@Override
	public Board detailBoard(int idx) {
		return boardDao.detailBoard(sqlSession, idx);
	}
	
	@Override
	public int countBoard(Board bo) {
		return boardDao.countBoard(sqlSession, bo);
	}
	
	@Override
	public int updateBoard(Board bo) {
		return boardDao.updateBoard(sqlSession, bo);
	}
	
	@Override
	public int deleteBoard(Board bo) {
		return boardDao.deleteBoard(sqlSession, bo);
	}

	@Override
	public int uploadBoard(MultipartFile file) {
		return boardDao.uploadBoard(sqlSession, file);
	}

	@Override
	public int searchListCount(String searchTxt) {
		return boardDao.searchListCount(sqlSession, searchTxt);
	}

	@Override
	public List<Board> searchListAll(PageInfo pi, String searchTxt) {
		return boardDao.searchListAll(sqlSession, pi, searchTxt);
	}
	
	
	
	
	
}
