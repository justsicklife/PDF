package kr.co.greenart.board.model.service;

import java.util.List;

import org.springframework.web.multipart.MultipartFile;

import kr.co.greenart.board.model.dto.Board;
import kr.co.greenart.common.model.dto.PageInfo;

public interface BoardService {
	// 전체 게시글 수 구하기
	// 추상 메서드 
	int selectListCount();
	
	// 목록 불러오기
	List<Board> selectListAll(PageInfo pi);
	
	// 글쓰기
	int insertBoard(Board bo);
	
	// 상세보기
	Board detailBoard(int idx);
	
	// 조회수
	int countBoard(Board bo);
	
	// 수정
	int updateBoard(Board bo);
	
	// 삭제
	int deleteBoard(Board bo);
	
	// 업로드
	int uploadBoard(MultipartFile file);
	
	// 검색 게시글 카운트
	int searchListCount(String searchTxt);
	
	// 검색 게시글 리스트
	public List<Board> searchListAll(PageInfo pi, String searchTxt);
}