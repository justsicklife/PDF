package kr.co.greenart.common.model.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class ParentDto {
	private int idx;
	private String title;
	private String content;
	private String writer;
	private int views;
	private int count;
	private String category;
	private String createDate;
	private String indate;
	private String updateDate;
	private String updateWriter;
	private String deleteDate;
	
	// file upload
	private String uploadPath;  // 경로
	private String uploadName;  // 변경된 파일명
	private String uploadOriginName;  // 원본 파일명
	
}