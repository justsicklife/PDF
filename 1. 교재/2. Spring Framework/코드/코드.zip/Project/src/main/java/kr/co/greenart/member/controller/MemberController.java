package kr.co.greenart.member.controller;

import java.util.Objects;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import kr.co.greenart.member.model.dto.Member;
import kr.co.greenart.member.model.service.MemberServiceImpl;

@Controller
@RequestMapping("/member")
public class MemberController {

	@Autowired
	MemberServiceImpl memberService;
	
	@PostMapping("/login.do")
	public String loginIndex(Member m, HttpSession session, Model model) {
		Member loginUser = memberService.loginMember(m);
		// Objects.isNull(loginUser) = null : true
		// !(논리부정) null : false , notNull : true
		// !true
		if(!Objects.isNull(loginUser)) {
			session.setAttribute("memberIdx", loginUser.getMemberIdx());
			session.setAttribute("msg", "로그인 되었습니다.");
			session.setAttribute("status", "success");
			return "redirect:/board/list.do";
		} else { // 로그인 실패
			model.addAttribute("msg", "아이디 또는 비밀번호를 확인해주세요.");
			model.addAttribute("status", "error");
			return "/member/login";
		}
	}
	
	@GetMapping("/redirect.do")
	public String redirectIndex(Model model) {
		model.addAttribute("msg", "잘못된 접근입니다.");
		model.addAttribute("status", "error");
		return "member/login";
	}
	
	// localhost/board/list.do
	// 로그인페이지로 이동(http://localhost/member/redirect.do)
}



















