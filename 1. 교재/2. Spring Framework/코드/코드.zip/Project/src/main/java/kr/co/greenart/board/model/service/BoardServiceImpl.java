package kr.co.greenart.board.model.service;

import java.util.List;

import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import kr.co.greenart.board.model.dao.BoardDao;
import kr.co.greenart.board.model.dto.Board;
import kr.co.greenart.common.model.dto.PageInfo;

@Service
public class BoardServiceImpl implements BoardService {

	@Autowired
	private BoardDao boardDao;
	
	@Autowired
	private SqlSessionTemplate sqlSession;
	
	@Override
	public int selectListCount() {
		return boardDao.selectListCount(sqlSession);
	}
	
	@Override
	public List<Board> selectListAll(PageInfo pi) {
		return boardDao.selectListAll(sqlSession, pi);
	}
	
	
	
	
	
	
	
}
