package kr.co.greenart.board.model.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

// Ctrl + Shift + O    ==> 자동 import
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class Board {
	private int idx;
	private String title;
	private String content;
	private String writer;
	private String indate;
	private int count;
}
