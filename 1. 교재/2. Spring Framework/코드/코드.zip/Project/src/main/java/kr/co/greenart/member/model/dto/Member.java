package kr.co.greenart.member.model.dto;

import java.sql.Date;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class Member {
	private int memberIdx;
	private String memberEmail;
	private String memberName;
	private String memberPassword;
	private Date memberIndate;
	private Date memberRemoveDate;
}
