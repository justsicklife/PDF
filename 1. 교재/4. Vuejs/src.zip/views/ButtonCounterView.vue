<template>
  <ButtonCounter></ButtonCounter>
  <hr>
  <backgoundColorChange></backgoundColorChange>
  <hr>  
  <todoList></todoList>
</template>

<script>
import ButtonCounter from '../components/ButtonCounter.vue'
import backgoundColorChange from '../components/backgoundColorChange.vue'
import todoList from '../components/todoList.vue'

export default {
    components: {
      ButtonCounter,
      backgoundColorChange,
      todoList
    }
}
</script>
