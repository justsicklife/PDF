<template>
  <div id="btn">
    <!-- 기능1 -->
    <button @click="goHome">홈으로 돌아가기</button>
    <br>
    <button @click="count2++">
      First : {{ count2 }}번 클릭 되었습니다.
    </button>
  </div>
</template>

<script>
export default {
  data() {
    return {
      count2: 0
    }
  },
  methods: {
    goHome: function() {
      this.$router.push('/');
    }
  }
}
</script>
