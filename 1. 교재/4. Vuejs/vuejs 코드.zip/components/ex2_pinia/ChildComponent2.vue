<template>
  <div>
    <p>클릭된 횟수 : {{ getCount }}</p>

    <input type="text" v-model="id">
    <button @click="submitId">제출</button>
  </div>
</template>

<script>
import { mapActions, mapState } from 'pinia'
import { compStore } from '../../stores/ex2Component'

export default {
  data() {
    return {
      id: ''
    }
  },
  computed: {
    ...mapState(compStore, ['getCount'])
  },
  methods: {
    ...mapActions(compStore, ['inputId']),
    submitId() {
        this.inputId(this.id)
    }
  },
}
</script>