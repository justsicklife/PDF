<template>
  <div>
    <button @click="Increment">Increment</button>
    <p>Child Count : {{ getCount }}</p>
  </div>
</template>

<script>
import {mapActions, mapState} from 'pinia'
import { compStore } from '../../stores/ex2Component'

export default {
  computed: {
    ...mapState(compStore, ['getCount'])
  },
  methods: {
    ...mapActions(compStore, ['incrementCount']),
    Increment() {
      this.incrementCount();
    }
  }
}
</script>