<template>
    <h1>할 일 목록({{getCount}}개)</h1>
    <input type="text" v-model="newTask" />
    <button @click="addTask">추가</button>
</template>

<script>
import { mapActions, mapState } from 'pinia'
import { todoStore } from '../../stores/todo'

export default {
    data() {
        return {
            newTask: ''
        }
    },
    computed: {
        ...mapState(todoStore, ['getCount'])
    },
    methods: {
        ...mapActions(todoStore, ['addList']),
        addTask() {
            this.addList(this.newTask);
            this.newTask = '';
        }
    }


}
</script>