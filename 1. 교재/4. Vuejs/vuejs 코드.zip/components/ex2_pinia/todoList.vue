<template>
  <ul>
    <li v-for="(task, index) in getList" :key="index">
      {{ task }}
      <button @click="deleteTask(index)">삭제</button>
    </li>
  </ul>
</template>

<script>
import { mapActions, mapState } from 'pinia'
import { todoStore } from '../../stores/todo'

export default {
  computed: {
    ...mapState(todoStore, ['getList'])
  }, 
  methods: {
    ...mapActions(todoStore, ['removeList']),
    deleteTask(index) {
      this.removeList(index);
    }
  }
}
</script>