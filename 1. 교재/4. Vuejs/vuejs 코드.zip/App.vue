<template>
  <div id="app">
    <!-- App.vue 페이지 -->
    App.vue 페이지

    <!-- 가져온 페이지 정보 보여주는 공간 -->
    <router-view></router-view>
  </div>
</template>