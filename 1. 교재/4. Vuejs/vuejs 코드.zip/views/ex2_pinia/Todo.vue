<template>
  <todoAdd></todoAdd>
  <todoList></todoList>
</template>

<script>
import todoList from '../../components/ex2_pinia/todoList.vue'
import todoAdd from '../../components/ex2_pinia/todoAdd.vue'

export default {
  components: {
    todoList,
    todoAdd
  }
}
</script>