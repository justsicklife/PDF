<template>
  <div id="btn">
    <button @click="count2++">
      Second : {{ count2 }}번 클릭 되었습니다.
    </button>
  </div>
</template>

<script>
export default {
  data() {
    return {
      count2: 0
    }
  }
}
</script>