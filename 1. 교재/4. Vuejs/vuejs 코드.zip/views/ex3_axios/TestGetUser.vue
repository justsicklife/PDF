<template>
  <button @click="getData">GetUser</button>
</template>

<script>
import axios from 'axios'

export default {
  data() {
    return {
      users: []
    }
  },
  methods: {
    getData() {
      // REST API 호출할 수 있는 샘플 데이터를 제공하는 사이트
      axios.get('http://localhost:8080/free/list.do')
      .then((response) => {
        this.users.push(response.data.list);
        // console.log(response);
        // this.users = response.data;
        // console.log(this.users);
      })
      .catch((error) => {
        console.log(error);
      })

      // console.log(this.users);
      this.$emit('users', this.users);
    }
  }
}
</script>
