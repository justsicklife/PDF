<template>
  <main class="flex-shrink-0">
    <br><br><br>
    <div class="container">
		<h3>글쓰기</h3>
		<hr>
		<br/>
			<div class="mb-3 justify-content-center">
				<input type="text" class="form-control"
                name="title" id="exampleFormControlInput1" 
                placeholder="제목을 입력하세요."
                v-model="data.title">
			</div>
			
			<div id="smarteditor mb-3 justify-content-center">
				<textarea name="content" id="editorTxt"
                  class="form-control"
                  rows="13" cols="10"
                  placeholder="내용을 입력해주세요"
                  v-model="data.content"></textarea>
      </div>
				
      <input type="file" name="upload" />
			<div class="row">
				<div class="col text-center">
					<button type="button" class="btn btn-danger" onclick="history.back()">취소</button>
					<button type="submit" @click="submitData" class="btn btn-primary">작성</button>
				</div>
			</div>
    </div>
  </main>
</template>

<script>
import axios from 'axios'

export default {
  data(){
    return {
      data: {
        title: '',
        content: ''
      }
    }
  },
  methods: {
    submitData() {
      axios.post('http://localhost:8080/free/insert.do', this.data)
      .then((response) =>{
        if(response.data === "success") {
          console.log(response);
          this.$router.push({ name: 'home' });
        }
      })
      .catch((error) =>{
        console.log(error);
      })
    }
  }
}
</script>