<template>
  <nav>
    <ul>
      <li>
        <!-- HTML의 a태그 -->
        <router-link to="/first">First</router-link>
      </li>
      <li>
        <router-link to="/second">Second</router-link>
      </li>
      <li>
        <router-link to="/third">Third</router-link>
      </li>
      <li>
        <router-link to="/buttonCounter">ButtonCounter</router-link>
      </li>
      <li>
        <router-link to="/parentComponent">ParentComponent</router-link>
      </li>
      <li>
        <router-link to="/pinia">pinia</router-link>
      </li>
      <li>
        <router-link to="/todo">todo</router-link>
      </li>
      <li>
        <router-link to="/axiosTest">axiosTest</router-link>
      </li>
      <li>
        <router-link to="/boardList">boardList</router-link>
      </li>
    </ul>
  </nav>
</template>

