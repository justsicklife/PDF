import {defineStore} from "pinia";

export const listStore = defineStore('List', {
  // 데이터들 모아놓는 공간
  state() {
    return {
      list: []
    }
  },
  // 데이터 변경, API 호출, 비동기 작업 등 기능을 수행하는 공간
  actions: {
    addList(data) {
      this.list.push(data)
    }
  },
  //  데이터 접근, 데이터에 대한 연산 등을 수행하는 공간
  getters: {
    getList(state) {
      return state.list;
    }
  }
})