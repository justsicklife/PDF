import {defineStore} from "pinia";

export const todoStore = defineStore('List', {
  state() {
    return {
      list: []
    }
  },
  actions: {
    addList(data) {
      this.list.push(data);
    },
    removeList(index) {
      this.list.splice(index, 1);
    }
  },
  getters: {
    getCount(state) {
      return state.list.length;
    },
    getList(state) {
      return state.list;
    }
  }
})