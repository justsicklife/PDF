import { defineStore } from "pinia";

export const compStore = defineStore('comp', {
  state() {
    return {
      count: 0,
      name: '',
      age: 0,
      addr: '',
      id: ''
    }
  },
  actions: {
    incrementCount() {
      this.count++;
    },
    inputId(id) {
      this.id = id
    }
  }, 
  getters: {
    getCount(state) {
      return state.count;
    },
    getId(state) {
      return state.id;
    }
  }
})