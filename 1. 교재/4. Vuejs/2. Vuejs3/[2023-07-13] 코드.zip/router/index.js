import { createRouter, createWebHistory } from "vue-router";
import First from '../views/FirstPage.vue'
import Second from '../views/SecondPage.vue'
import Third from '../views/ThirdPage.vue'
import NotFound from '../views/NotFound.vue'
import Home from '../views/Home.vue'

import ButtonCounter from '../views/ButtonCounterView.vue'
import ParentComponent from '../views/ex2_pinia/ParentComponent.vue'
import Pinia from '../views/ex2_pinia/List.vue'
import Todo from '../views/ex2_pinia/Todo.vue'

const routes = [
  { path: '/', name:"home", component: Home },
  { path: '/first', name:"first", component: First },
  { path: '/second', name:"second", component: Second },
  { path: '/third', name:"third", component: Third },
  { path: '/buttonCounter', name:"buttonCounter", component: ButtonCounter },
  { path: '/parentComponent', name:"parentComponent", component: ParentComponent },
  { path: '/pinia', name:"pinia", component: Pinia },
  { path: '/todo', name:"todo", component: Todo },
  { path: '/404', name:"notFound", component: NotFound },
  { path: '/:pathMatch(.*)*', redirect: "/404"}
];

const router = createRouter ({
  history: createWebHistory(),
  routes
})

export default router;
