<template>
  <div>
    <h1>Parent Component</h1>
    <p>버튼 클릭한 횟수 : {{ getCount }}</p>
    <hr>
    <ChildComponent />
    <p>아이디 : {{ getId }}</p>
    <hr>
    <br>
    <ChildComponent2 />

    <br><br><br><br><br><br><br><br><br><br>
  </div>
</template>

<script>
import ChildComponent from '../../components/ex2_pinia/ChildComponent.vue'
import ChildComponent2 from '../../components/ex2_pinia/ChildComponent2.vue'
import { mapActions, mapState } from 'pinia'
import { compStore } from '../../stores/ex2Component'

export default {
  
  components: {
    ChildComponent,
    ChildComponent2
  },
  computed: {
    ...mapState(compStore, ['getId']),
    ...mapState(compStore, ['getCount'])
  }
}
</script>