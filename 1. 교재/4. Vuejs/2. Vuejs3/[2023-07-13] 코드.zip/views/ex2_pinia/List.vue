<template>
  <div>
    <input type="text" v-model="id" />
    <button @click="addUserList">추가</button>

    <p v-for="(item, index) in getList" :key="index">
      {{ item }}
    </p>
  </div>
</template>

<script>
import { mapActions, mapState } from 'pinia';
import { listStore } from '../../stores/list';

export default {
  data() {
    return {
      // abc
      id: ''
    }
  },
  computed: {
    ...mapState(listStore, ['getList'])
  },
  methods: {
    ...mapActions(listStore, ['addList']),
    addUserList() {
      this.addList(this.id);
      this.id = '';
    }
  }
}
</script>