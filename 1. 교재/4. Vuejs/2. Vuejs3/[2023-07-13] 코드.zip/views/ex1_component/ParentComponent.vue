<template>
  <div>
    <h1>Parent Component</h1>
    <p>버튼 클릭한 횟수 : {{ count }}</p>
    <ChildComponent @increment="parentIncrement"
                    @getName="parentGetName"
                    :age="ageData"
                    :addr="address" 
                    :id="id"/>
    <p>이름 : {{ name }}</p>
    <br>
    <hr>
    <br>
    <ChildComponent2  @submitId="submitId"
                      :age="ageData"
                      :addr="address"
                      :count="count"
                      :name="name"/>

    <br><br><br><br><br><br><br><br><br><br>
  </div>
</template>

<script>
import ChildComponent from '../../components/ex1_component/ChildComponent.vue'
import ChildComponent2 from '../../components/ex1_component/ChildComponent2.vue'

export default {
  components: {
    ChildComponent,
    ChildComponent2
  },
  data() {
    return {
      count: 0,
      name: '',
      ageData: 21,
      address: '인천시',
      id: ''
    }
  },
  methods: {
    parentIncrement: function(count) {
      this.count = count
    },
    parentGetName: function(name) {
      this.name = name
    },
    submitId: function(id){
      this.id = id
    }
  }
}
</script>