<template>
  <div>
    <p>클릭된 횟수 : {{ count }}</p>
    <p>이름 : {{ name }}</p>
    <p>나이 : {{ age }}</p>
    <p>주소 : {{ addr }}</p>

    <input type="text" v-model="id">
    <button @click="submitId">제출</button>
  </div>
</template>

<script>
export default {
  props: ['age', 'addr', 'count', 'name'],
  data() {
    return {
      id: ''
    }
  },
  methods: {
    submitId: function() {
      this.$emit('submitId', this.id);
    }
  }

}
</script>